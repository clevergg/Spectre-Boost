import { FirstCard } from "./components/FirstCard"
import { FrameAnimation } from "../../shared/ui/FrameAnimation"
import { SecondCard } from "./components/SecondCard"
import { ServicesLinks } from "../../shared/ui/ServicesLinks/ServicesLinks"
import { TitleTemplate } from "../../shared/ui/TitleTemplate"

const Calculator = () => {
  return (
    <section className='w-full pt-[calc(7rem+7vw)] xl:pt-[calc(5.5rem+5.5vw)] pb-[calc(4rem+4vw)] flex flex-col space-y-8 relative'>
      <TitleTemplate
        text='ПРОКАЧАЙТЕ СВОЙ АККАУНТ В PUBG'
        className='text-[clamp(1.8rem,4.8vw,5rem)]/[115%] font-black font-unbounded md:pb-7 text-white text-balance text-center'
      />
      <ServicesLinks />
      <FrameAnimation className='flex max-lg:flex-col max-lg:space-y-10 lg:space-x-5 xl:space-x-10 justify-between z-1 min-h-full'>
        <FirstCard />

        <SecondCard />
      </FrameAnimation>
    </section>
  )
}

export default Calculator
