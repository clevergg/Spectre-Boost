export { default } from "./Survivor"
