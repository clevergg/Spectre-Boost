import { useEffect } from "react"
import { createPortal } from "react-dom"
import { FrameAnimation } from "../../../shared/ui/FrameAnimation"
import type { ReactNode } from "react"
import { lockScroll, unlockScroll } from "../../../core/helpers/controlScroll"

interface AuthModalProps {
  isOpen: boolean
  onClose: () => void
  children: ReactNode
  type?: string
}

const CreatePortalModal = ({ isOpen, onClose, children, type = "default" }: AuthModalProps) => {
  useEffect(() => {
    const handleEscape = (event: KeyboardEvent): void => {
      if (isOpen && event.key === "Escape") onClose()
    }

    if (isOpen) {
      document.addEventListener("keydown", handleEscape)
    }

    return () => {
      document.removeEventListener("keydown", handleEscape)
    }
  }, [isOpen, onClose])

  useEffect(() => {
    if (isOpen) {
      lockScroll()
    }

    return () => unlockScroll()
  }, [isOpen])

  if (!isOpen) return null

  const modalRootDiv = document.getElementById("modal-root")

  return createPortal(
    <FrameAnimation
      key={JSON.stringify(isOpen)}
      className='fixed inset-0 z-50 flex items-center justify-center min-w-[360px] bg-black/90 bg-opacity-70'
    >
      <div className='absolute inset-0' onClick={onClose} aria-hidden='true' />
      <div
        className={`relative bg-black border border-gray-dark rounded-lg text-center ${type !== "default" ? "min-w-[310px] max-w-3/4 lgx:max-w-1/2" : "max-w-[325px]"} w-full p-5`}
      >
        {children}
      </div>
    </FrameAnimation>,
    modalRootDiv!
  )
}

export default CreatePortalModal
